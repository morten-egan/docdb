var docdbControllers = angular.module('docdbControllers', []);

