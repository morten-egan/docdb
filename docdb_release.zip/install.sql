@@docdb_parse.pks
@@docdb_tools.pks
@@docdb_write.pks
@@docdb.pks
@@docdb_parse.pkb
@@docdb_tools.pkb
@@docdb_write.pkb
@@docdb.pkb

grant execute on docdb to public;
create public synonym docdb for docdb;